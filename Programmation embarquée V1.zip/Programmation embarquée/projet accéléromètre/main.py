 
from drv_lsm6dsox import *
from setting import *
import math

if __name__ == "__main__":
        driver = drv_lsm6dsox(bus=I2C_BUS)
        while True:
            x_a, y_a, z_a = driver.read_accel()
            x_g, y_g, z_g = driver.read_gyro()
            #verifier leur indentation 
            angle_x = math.degrees(math.atan2(y_a * SF_2G,z_a * SF_2G))
            angle_y = math.degrees(math.atan2(x_a * SF_2G, z_a * SF_2G))
            time.sleep(READ_DELAY)
