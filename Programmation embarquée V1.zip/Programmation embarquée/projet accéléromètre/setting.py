LSM6DSOX_ADDR = 0x6A


I2C_BUS = 1
BLOCK_SIZE = 6  # 6 octets = 2 octets par axe (X, Y, Z)

FQ_POWER_DOWN = 0x00   # gyroscope disabled
FQ12_5HZ      = 0x10
FQ26HZ        = 0x20
FQ52HZ        = 0x30
FQ104HZ       = 0x40
FQ208HZ       = 0x50
FQ416HZ       = 0x60
FQ833HZ       = 0x70
FQ1660HZ      = 0x80  # 1.66 kHz
FQ3330HZ      = 0x90  # 3.33 kHz
FQ6660HZ      = 0xA0  # 6.66 kHz


FS_2G  = 0x00
FS_16G = 0x04
FS_4G  = 0x08
FS_8G  = 0x0C

CTRL3_C_BOOT      = 0x80  # Bit 7: Reboot memory content
CTRL3_C_BDU       = 0x40  # Bit 6: Block Data Update
CTRL3_C_H_LACTIVE = 0x20  # Bit 5: Interrupt active level (0: high, 1: low)
CTRL3_C_PP_OD     = 0x10  # Bit 4: Push-pull / Open-drain selection for INT1/INT2
CTRL3_C_SIM       = 0x08  # Bit 3: SPI Serial Interface Mode selection (0: 4-wire, 1: 3-wire)
CTRL3_C_IF_INC    = 0x04  # Bit 2: Register address auto-increment enable (1: enabled)
# Bit 1 is reserved and should be kept at 0
CTRL3_C_SW_RESET  = 0x01  # Bit 0: Software Reset

READ_DELAY = 0.1

SF_2G   = 0.000061
SF_4G   = 0.000122
SF_8G   = 0.000244
SF_16G  = 0.000488

SF_G_125DPS   = 0.004375
SF_G_245DPS   = 0.00875
SF_G_500DPS   = 0.0175
SF_G_1000DPS  = 0.035
SF_G_2000DPS  = 0.07