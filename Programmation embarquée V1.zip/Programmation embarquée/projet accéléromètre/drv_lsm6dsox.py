import time
import smbus2
from setting import *
CTRL1_XL    = 0x10  # Accelerometer configuration (ODR, range, etc.)
CTRL2_G     = 0x11  # Gyroscope configuration (ODR, range, etc.)
CTRL3_C     = 0x12  # General configuration (BDU, auto-increment...)
OUTX_L_G    = 0x22  # Start of gyroscope data registers (6 bytes)
OUTX_L_XL   = 0x28  # Start of accelerometer data registers (6 bytes)



class drv_lsm6dsox:
    def __init__(self, bus=I2C_BUS, adresse=LSM6DSOX_ADDR):
        # Open the I2C bus (bus=1 for Raspberry Pi)
        self.bus = smbus2.SMBus(bus)
        self.adresse = adresse
        self.init_lsm6dsox()

 #ici ajouté par ia de vs code APRES NOM fonctions 
    def init_lsm6dsox(self):

       
        # Initialize the LSM6DSOX sensor
        self.bus.write_byte_data(self.adresse, CTRL3_C, CTRL3_C_BDU | CTRL3_C_IF_INC)  # Enable BDU and auto-increment
        self.bus.write_byte_data(self.adresse, CTRL1_XL, FQ104HZ | FS_2G)  # Set accelerometer to 104 Hz and ±2g
        self.bus.write_byte_data(self.adresse, CTRL2_G, FQ104HZ | FS_245DPS)  # Set gyroscope to 104 Hz and ±245 dps

    def read_accel(self):
        
        # Read accelerometer data
        data = self.bus.read_i2c_block_data(self.adresse, OUTX_L_XL, BLOCK_SIZE)
        # Convert to signed integers
        x = (data[1] << 8) | data[0]
        y = (data[3] << 8) | data[2]
        z = (data[5] << 8) | data[4]
        # Apply scaling factor
        x = x * SF_2G
        y = y * SF_2G
        z = z * SF_2G
        return x, y, z

    def read_gyro(self):
    
        # Read gyroscope data
        data = self.bus.read_i2c_block_data(self.adresse, OUTX_L_G, BLOCK_SIZE)
        # Convert to signed integers
        x = (data[1] << 8) | data[0]
        y = (data[3] << 8) | data[2]
        z = (data[5] << 8) | data[4]
        # Apply scaling factor
        x = x * SF_G_245DPS
        y = y * SF_G_245DPS
        z = z * SF_G_245DPS
        return x, y, z


        def _twos_complement(self, val, bits):
            """Compute the 2's complement of int value val"""
            if (val & (1 << (bits - 1))) != 0:  # if sign bit is set e.g., 8bit: 128-255
                val = val - (1 << bits)         # compute negative value
            return val

        