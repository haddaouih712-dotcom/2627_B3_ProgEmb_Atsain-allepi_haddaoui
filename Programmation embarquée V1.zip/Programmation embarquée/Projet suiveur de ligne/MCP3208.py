import spidev

BIT_START = 4
BIT_CONV_SINGLE = 2


class MCP3208:
    def __init__(self, spi_bus=0, spi_device=0, clock_speed=1e6, vref=3.3):
        self.spi = spidev.SpiDev()
        self.spi.open(spi_bus, spi_device)
        self.spi.max_speed_hz = clock_speed
        self.vref = vref

    def read_channel(self, channel):
        command = [BIT_START | BIT_CONV_SINGLE | (channel >> 2), (channel & 3) << 6, 0]
        result = self.spi.xfer2(command)
        value = ((result[1] & 15) << 8 ) | result[2]
        return value

# à faire ds la meme classe (hypothtses suite de la fonction)
    def read_voltage(self, channel):
        raw_value = self.read_channel(channel)
        voltage = (raw_value / 4095.0) * self.vref
        return voltage
    def read_all_channels(self):
        return [self.read_voltage(ch) for ch in range(8)]
    def close(self):
        self.spi.close()

