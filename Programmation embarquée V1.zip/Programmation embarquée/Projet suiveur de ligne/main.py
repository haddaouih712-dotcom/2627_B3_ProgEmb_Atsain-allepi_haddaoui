
from line_detector import * 
from MCP3208 import *
import time


def main():
    IFR = MCP3208(vref=3.3)
    try:
        print("Line follower started.")
        while True:
            position = detect_line(IFR, threshold=THRESHOLD)
            time.sleep(DELAY)
    except KeyboardInterrupt:
        # Handles manual interruption (Ctrl+C)
        IFR.close()
        print("\nProgram stopped.")
    except Exception as e:
        IFR.close()
        print(f"Error detected: {e}")
    if __name__ == "__main__":
        main()