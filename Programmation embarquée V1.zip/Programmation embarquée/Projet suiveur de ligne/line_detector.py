
from MCP3208 import *
import time

THRESHOLD = 1.5

def detect_line(IFR, threshold=THRESHOLD):
    sensor_0 = IFR.read_voltage(0)
    sensor_1 = IFR.read_voltage(1)
    sensor_2 = IFR.read_voltage(2)
    sensor_3 = IFR.read_voltage(3)
    sensor_4 = IFR.read_voltage(4)
    sensor_5 = IFR.read_voltage(5)
    sensor_6 = IFR.read_voltage(6)
    sensor_7 = IFR.read_voltage(7)
    print(position)
    time.sleep(0.2)
    return position
